//package com.eliving.tv.data.db
//
//import androidx.room.Database
//import androidx.room.RoomDatabase
//import com.eliving.tv.service.user.model.db.User
//import com.eliving.tv.service.user.dao.UserDao
//
//@Database(entities = [User::class], version = 1)
//abstract class AppDataBase : RoomDatabase(){
//
//    abstract fun getUserDao(): UserDao
//}