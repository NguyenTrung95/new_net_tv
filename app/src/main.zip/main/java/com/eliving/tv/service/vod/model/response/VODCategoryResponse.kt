package com.eliving.tv.service.vod.model.response

open class VODCategoryResponse()  {

}