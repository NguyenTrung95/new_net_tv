package com.eliving.tv.customview.textfieldboxes;

public interface SimpleTextChangedWatcher {

    void onTextChanged(String theNewText, boolean isError);
}
