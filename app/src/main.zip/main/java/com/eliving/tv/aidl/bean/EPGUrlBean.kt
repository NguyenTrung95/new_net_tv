package com.eliving.tv.aidl.bean

class EPGUrlBean {
    var duration: Long = 0
    var url: String? = null

}